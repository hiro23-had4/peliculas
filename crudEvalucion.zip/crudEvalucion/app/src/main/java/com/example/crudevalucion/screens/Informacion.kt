package com.example.crudevalucion.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.crudevalucion.navigate.AppScreen

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun InformacionPlantas(
    navController: NavController,
    img: String,
    nombre: String,
    descripcion: String,
    valoracion: String,
    link: String,
) {
    Scaffold(
        topBar = {
                Row(modifier = Modifier.fillMaxWidth().background(color = Color.Blue)) {
                    Icon(
                        modifier = Modifier.clickable {
                            navController.navigate(AppScreen.ListaPlantas.route)
                        },
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Regresar", tint = Color.Black
                    )
                    Text(text = "Detalles",
                        modifier = Modifier.clickable {
                            navController.navigate(AppScreen.ListaPlantas.route)
                        }, color = Color.Black)
                } // fin column

        }) {
        BodyInformacion(navController, img, nombre, descripcion, valoracion, link)
    }
}

@Composable
fun BodyInformacion(
    navController: NavController,
    img: String,
    nombre: String,
    descripcion: String,
    valoracion: String,
    link: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(count = 1)
            {
                Image(
                    painter = rememberAsyncImagePainter(img),
                    contentDescription = "Imagen",
                    modifier = Modifier.size(300.dp),
                    alignment = Alignment.Center,
                    contentScale = ContentScale.Inside
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = nombre,
                    style = MaterialTheme.typography.h4, color = Color.Black
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = descripcion,
                    color = Color.Black,
                    modifier = Modifier.align(alignment = Alignment.Start).padding(8.dp),
                )
                Text(text = valoracion, color = Color.Black)
                Spacer(modifier = Modifier.height(10.dp))

//                val uriHandler = LocalUriHandler.current
//                Text(text = "from wikipedia",
//                    modifier = Modifier
//                        .clickable {
//                            uriHandler.openUri(link)
//                        }
//                        .align(alignment = Alignment.Start), color = Color.Cyan
//                )
            }
        }
    }
}




