package com.example.crudevalucion.navigate

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.crudevalucion.login.LoginScreen
import com.example.crudevalucion.models.UsuarioViewModel
import com.example.crudevalucion.screens.HomeScreen
import com.example.crudevalucion.screens.InformacionPlantas
import com.example.crudevalucion.screens.ListaPlantas

@Composable
fun AppNavigate(forward: Boolean, onLoginClick: () -> Unit) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppScreen.LoginScreen.route
    ) {
        composable(AppScreen.LoginScreen.route) {
            if (forward) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(AppScreen.HomeScreen.route)
                    { popUpTo(AppScreen.LoginScreen.route) { inclusive = true } }
                }
            } else {
                LoginScreen(forward, onLoginClick)
            }
        } // fin del composable
        composable(AppScreen.HomeScreen.route) { HomeScreen(navController) }
        composable(AppScreen.ListaPlantas.route) { ListaPlantas(navController, UsuarioViewModel()) }


        composable(AppScreen.InformacionPlantas.route, arguments = listOf(
            navArgument("img") { type = NavType.StringType },
            navArgument("nombre") { type = NavType.StringType },
            navArgument("descripcion") { type = NavType.StringType },
            navArgument("valoracion") { type = NavType.StringType },
            navArgument("link") { type = NavType.StringType }
        )) {
            InformacionPlantas(
                navController,
                img = it.arguments?.getString("img") ?: "",
                nombre = it.arguments?.getString("nombre") ?: "",
                descripcion = it.arguments?.getString("descripcion") ?: "",
                valoracion = it.arguments?.getString("valoracion") ?: "",
                link = it.arguments?.getString("link") ?: ""
                )
        }
    }
}