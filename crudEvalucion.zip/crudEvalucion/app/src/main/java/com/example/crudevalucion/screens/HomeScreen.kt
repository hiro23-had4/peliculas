package com.example.crudevalucion.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mode
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.crudevalucion.models.Usuario
import com.example.crudevalucion.navigate.AppScreen
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            navController.navigate(AppScreen.HomeScreen.route)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = null,
                            tint = Color.Yellow
                        )
                        Text(text = "Agregar", color = Color.Black)
                    } // fin column
                    Column(verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            navController.navigate(AppScreen.ListaPlantas.route)
                        }) {
                        Icon(
                            imageVector = Icons.Default.Mode,
                            contentDescription = null,
                            tint = Color.Yellow
                        )
                        Text(text = "Peliculas", color = Color.Black)
                    }
                }
            }

        }) {
        BodyContent(navController)
    }
}

@Composable
fun BodyContent(navController: NavController) {
    var img by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var valoracion by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = MaterialTheme.colors.primary)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {
            items(count = 1) {
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(width = 2.dp, color = Color.Black),
                    value = img,
                    onValueChange = { img = it },
                    label = { Text(text = "foto:", color = Color.Black) },

                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(width = 2.dp,  color = Color.Black),
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text(text = "Nombre", color = Color.Black) },

                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(width = 2.dp, color = Color.Black),
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text(text = "Descripcion:", color = Color.Black) },

                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(width = 2.dp, color = Color.Black),
                    value = valoracion,
                    onValueChange = { valoracion = it },
                    label = { Text(text = "valoracion:",color = Color.Black) },

                )
                Spacer(modifier = Modifier.height(20.dp))
//                TextField(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .border(width = 2.dp, color = Color.Black),
//                    value = link,
//                    onValueChange = { link = it },
//                    label = { Text(text = "Link:", color = Color.Black) },
//
//                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Yellow),
                    onClick = {
                        val usuario = Usuario(img, nombre, descripcion, valoracion, link)
                        Firebase.firestore.collection("usuarios").add(usuario)

                        navController.navigate(AppScreen.ListaPlantas.route)
                    },
                    modifier = Modifier
                        .padding(vertical = 8.dp, horizontal = 110.dp).fillMaxWidth(), shape = RoundedCornerShape(5.dp)

                ) {
                    Text(text = "Agregar Pelicula", color = Color.Black)
                }
            }
        } // fin Lazycolumm
    }
}

