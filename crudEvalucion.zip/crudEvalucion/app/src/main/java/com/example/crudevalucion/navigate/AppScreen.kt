package com.example.crudevalucion.navigate

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class AppScreen(val route: String) {
    object LoginScreen : AppScreen("LoginScreen")
    object HomeScreen : AppScreen("HomeScreen")
    object ListaPlantas : AppScreen("ListaPlantas")
    object InformacionPlantas :
        AppScreen(route = "InformacionPlantas/{img}/{nombre}/{descripcion}/{valoracion}/{link}") {
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun router_New(
            img: String,
            nombre: String,
            descripcion: String,
            valoracion: String,
            link: String
        ): String {
            return "InformacionPlantas/${img.encodeUrl()}/$nombre/$descripcion/$valoracion/${link.encodeUrl()}"
        }
    }
}
