package com.example.crudevalucion.models

data class Usuario(
    val img: String = "",
    val nombre: String = "",
    val valoracion: String = "",
    val descripcion: String = "",
//    val categoria: String = "",
    val link: String = ""
)


