package com.example.crudevalucion.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.Button
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.example.crudevalucion.R

@Composable
fun LoginScreen(
    isLoading: Boolean,
    onLoginClick: () -> Unit
) {
    val logo = painterResource(id = R.drawable.logo)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    )
    {
        Text(
            stringResource(id = R.string.Title_Main),
            style = MaterialTheme.typography.h3, color = Color.Black
        )
        Image(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.3f),
            painter = logo,
            contentDescription = "Logo"
        )
        Text(
            stringResource(id = R.string.Sub_Title),
            style = MaterialTheme.typography.h4, color = Color.Black
        )
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            Button(onClick = onLoginClick) {
                Text(text = stringResource(id = R.string.Login_cta), color = Color.Black)
            }
        }
        LegalText()
    }
}

@Composable
fun LegalText() {
    val anottatedString = buildAnnotatedString {
        append(stringResource(id = R.string.Text_Legal1))
        append(" ")
        pushStringAnnotation("URL", annotation = "app://terms")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ) {
            append(stringResource(id = R.string.Text_Legal2))
        }
        append(" ")
        pop()
        append(stringResource(id = R.string.Text_Legal3))
        append(" ")
        pushStringAnnotation("URL", annotation = "app://privacy")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ) {
            append(stringResource(id = R.string.Text_Legal4))
        }
        pop()
    } // fin anottatedString
    Box(contentAlignment = Alignment.Center) {
        ClickableText(
            modifier = Modifier.padding(24.dp),
            text = anottatedString,
        ) { offset ->
            anottatedString.getStringAnnotations("URL", offset, offset).firstOrNull()?.let { tag ->
                Log.d("App", "Ha dado click en ${tag.item}")
            } // fin firstornull
        } // fin text
    } // fin box
}
